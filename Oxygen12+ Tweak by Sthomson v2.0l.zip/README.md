# OxygenOS 12 Tweak by sthomsonpl
 
- Enable Blur on QS
- Force High Refresh Rate Display
- Fix Fod
- Enable VoLTE&Wifi Calling
- Increase JPEG quality
- Improve scrolling
- Improve RAM Management 
- Improve the using experience
- Disable share usage data

#Credits:

-NooB9496